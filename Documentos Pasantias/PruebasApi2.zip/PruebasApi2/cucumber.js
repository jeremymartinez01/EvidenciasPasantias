module.exports = {
    default: {
        tags: process.env.npm_config_TAGS || "",
        formatOptions: {
            snippetInterface: "async-await"
        },
        paths: [
            "src/ApiTest/features/*.feature"
        ],
        dryRun: false,
        require: [
            "src/ApiTest/steps/*.ts",
            "src/hooks/hooks.ts"
        ],
        color: true,
        requireModule: [
            "ts-node/register"
        ],
        format: [
            "progress-bar",
            "html:test-results/reportApi.html",
            "json:test-results/cucumber-report.json",
            "junit:test-results/cucumber-report.xml"
        ],
        //parallel: 2
    }
}