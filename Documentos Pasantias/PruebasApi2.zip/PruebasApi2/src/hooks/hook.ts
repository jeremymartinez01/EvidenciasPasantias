import { BeforeAll, AfterAll, Before, After, setDefaultTimeout } from "@cucumber/cucumber";
import { getEnv } from "../helper/env/env";
import logger from "../helper/util/logger";

setDefaultTimeout(60 * 1000 * 2)
BeforeAll(async function () {
    getEnv();
});

Before(async function ({ pickle }) {
    const scenarioName = pickle.name
    logger.info(scenarioName);
});

After(async function () {
    logger.warn("fin");
});