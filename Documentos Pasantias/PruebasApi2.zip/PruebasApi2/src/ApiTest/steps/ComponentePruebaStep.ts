import { Given, When, Then } from "@cucumber/cucumber";
import { request, expect } from "playwright/test";

import data = require('../data/OTP/otp.json');

let contextApi: any
let postResponse: any

Given('Contexto dado', async function (/*string, string2*/) {
    /*contextApi = await request.newContext({
        baseURL: process.env.BASEURL,
        extraHTTPHeaders: {
            'Content-Type': process.env.CONTENTJSON,
        }
    }); */
    console.log("Contexto dado")
    expect(true).toBe(true);
});

When('Accion:Envío una solicitud POST a {string} con el cuerpo de la solicitud', async function (string) {
    //Ejemplo con solicitud Post, modificar de acuerdo a los endpoints y metodos a probar
    //postResponse = await contextApi.post('resto del componente del endpoint', data);
    console.log("Accion")
    expect(true).toBe(true);
});

Then('Consecuencia:El código de estado de la respuesta debe ser 200', async function (/*status*/) {
    /*expect(postResponse.status()).toBe(status);
    console.log("Response " + postResponse.status());*/
    console.log("Consecuencia")
    expect(true).toBe(true);
});
Then('ConsecuenciaExtra', async function () {
    console.log("Consecuencia extra")
    expect(true).toBe(true);
});